<?php
$conn = mysqli_connect("localhost","root","","cafe_management");
?>

<!DOCTYPE html>
<html>
<head>
<title>Cafe Management System</title>
<link rel="stylesheet" href="style.css">
</head>

<body>

<h1>Cafe Management System</h1>

<form method="post">
Item Name:
<input type="text" name="item">

Price:
<input type="number" name="price">

Quantity:
<input type="number" name="qty">

<button name="order">Place Order</button>
</form>

<?php
if(isset($_POST['order']))
{
$item=$_POST['item'];
$price=$_POST['price'];
$qty=$_POST['qty'];
$total=$price*$qty;

mysqli_query($conn,"INSERT INTO orders(item_name,quantity,total)
VALUES('$item','$qty','$total')");

echo "Order placed. Total = ".$total;
}
?>

</body>
</html>
