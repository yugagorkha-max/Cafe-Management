CREATE DATABASE cafe_management;

USE cafe_management;

CREATE TABLE orders(
order_id INT AUTO_INCREMENT PRIMARY KEY,
item_name VARCHAR(50),
quantity INT,
total INT
);
