# Cafe Management System

Simple cafe management system using PHP and MySQL.

## Features
- Place Order
- Simple Billing
- Database storage

## Technologies
- HTML
- CSS
- PHP
- MySQL
- XAMPP

## Run Project
1. Install XAMPP
2. Start Apache and MySQL
3. Import database.sql in phpMyAdmin
4. Open http://localhost/cafe/index.php

## Author
Yuga Naresh Gorkha
